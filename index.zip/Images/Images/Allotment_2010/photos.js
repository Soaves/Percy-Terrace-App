WPGgallery = new Object();
WPGgallery.name = Early_Summer_Allotment_2010;
WPGgallery.photographer = "Paul Penman";
WPGgallery.contact = "Paul Penman";
WPGgallery.email = "paul@alnwick-bedandbreakfast.co.uk";
WPGgallery.date = "04/07/2010"

WPGgallery.colors = new Object();
WPGgallery.colors.background = "#FFFFFF";
WPGgallery.colors.banner = "#F0F0F0";
WPGgallery.colors.text = "#000000";
WPGgallery.colors.link = "#0000FF";
WPGgallery.colors.alink = "#FF0000";
WPGgallery.colors.vlink = "#800080";

gPhotos = new Array();
gPhotos[0] = new Object();
gPhotos[0].filename = "DSC_0105_2695.jpg";
gPhotos[0].ImageWidth = 450;
gPhotos[0].ImageHeight = 299;
gPhotos[0].ThumbWidth = 75;
gPhotos[0].ThumbHeight = 49;
gPhotos[0].meta = new Object();

gPhotos[1] = new Object();
gPhotos[1].filename = "DSC_0106_2696.jpg";
gPhotos[1].ImageWidth = 450;
gPhotos[1].ImageHeight = 299;
gPhotos[1].ThumbWidth = 75;
gPhotos[1].ThumbHeight = 49;
gPhotos[1].meta = new Object();

gPhotos[2] = new Object();
gPhotos[2].filename = "DSC_0108_2698.jpg";
gPhotos[2].ImageWidth = 450;
gPhotos[2].ImageHeight = 299;
gPhotos[2].ThumbWidth = 75;
gPhotos[2].ThumbHeight = 49;
gPhotos[2].meta = new Object();

gPhotos[3] = new Object();
gPhotos[3].filename = "DSC_0109_2699.jpg";
gPhotos[3].ImageWidth = 450;
gPhotos[3].ImageHeight = 299;
gPhotos[3].ThumbWidth = 75;
gPhotos[3].ThumbHeight = 49;
gPhotos[3].meta = new Object();

gPhotos[4] = new Object();
gPhotos[4].filename = "DSC_0110_2700.jpg";
gPhotos[4].ImageWidth = 450;
gPhotos[4].ImageHeight = 299;
gPhotos[4].ThumbWidth = 75;
gPhotos[4].ThumbHeight = 49;
gPhotos[4].meta = new Object();

gPhotos[5] = new Object();
gPhotos[5].filename = "DSC_0111_2701.jpg";
gPhotos[5].ImageWidth = 450;
gPhotos[5].ImageHeight = 299;
gPhotos[5].ThumbWidth = 75;
gPhotos[5].ThumbHeight = 49;
gPhotos[5].meta = new Object();

gPhotos[6] = new Object();
gPhotos[6].filename = "DSC_0112_2702.jpg";
gPhotos[6].ImageWidth = 450;
gPhotos[6].ImageHeight = 299;
gPhotos[6].ThumbWidth = 75;
gPhotos[6].ThumbHeight = 49;
gPhotos[6].meta = new Object();

gPhotos[7] = new Object();
gPhotos[7].filename = "DSC_0113_2703.jpg";
gPhotos[7].ImageWidth = 450;
gPhotos[7].ImageHeight = 299;
gPhotos[7].ThumbWidth = 75;
gPhotos[7].ThumbHeight = 49;
gPhotos[7].meta = new Object();

gPhotos[8] = new Object();
gPhotos[8].filename = "DSC_0114_2704.jpg";
gPhotos[8].ImageWidth = 450;
gPhotos[8].ImageHeight = 299;
gPhotos[8].ThumbWidth = 75;
gPhotos[8].ThumbHeight = 49;
gPhotos[8].meta = new Object();

gPhotos[9] = new Object();
gPhotos[9].filename = "DSC_0115_2705.jpg";
gPhotos[9].ImageWidth = 450;
gPhotos[9].ImageHeight = 299;
gPhotos[9].ThumbWidth = 75;
gPhotos[9].ThumbHeight = 49;
gPhotos[9].meta = new Object();

gPhotos[10] = new Object();
gPhotos[10].filename = "DSC_0116_2706.jpg";
gPhotos[10].ImageWidth = 450;
gPhotos[10].ImageHeight = 299;
gPhotos[10].ThumbWidth = 75;
gPhotos[10].ThumbHeight = 49;
gPhotos[10].meta = new Object();

gPhotos[11] = new Object();
gPhotos[11].filename = "DSC_0117_2707.jpg";
gPhotos[11].ImageWidth = 450;
gPhotos[11].ImageHeight = 299;
gPhotos[11].ThumbWidth = 75;
gPhotos[11].ThumbHeight = 49;
gPhotos[11].meta = new Object();

gPhotos[12] = new Object();
gPhotos[12].filename = "DSC_0118_2708.jpg";
gPhotos[12].ImageWidth = 450;
gPhotos[12].ImageHeight = 299;
gPhotos[12].ThumbWidth = 75;
gPhotos[12].ThumbHeight = 49;
gPhotos[12].meta = new Object();

gPhotos[13] = new Object();
gPhotos[13].filename = "DSC_0119_2709.jpg";
gPhotos[13].ImageWidth = 450;
gPhotos[13].ImageHeight = 299;
gPhotos[13].ThumbWidth = 75;
gPhotos[13].ThumbHeight = 49;
gPhotos[13].meta = new Object();

gPhotos[14] = new Object();
gPhotos[14].filename = "DSC_0120_2710.jpg";
gPhotos[14].ImageWidth = 450;
gPhotos[14].ImageHeight = 299;
gPhotos[14].ThumbWidth = 75;
gPhotos[14].ThumbHeight = 49;
gPhotos[14].meta = new Object();

gPhotos[15] = new Object();
gPhotos[15].filename = "DSC_0121_2711.jpg";
gPhotos[15].ImageWidth = 450;
gPhotos[15].ImageHeight = 299;
gPhotos[15].ThumbWidth = 75;
gPhotos[15].ThumbHeight = 49;
gPhotos[15].meta = new Object();

gPhotos[16] = new Object();
gPhotos[16].filename = "DSC_0122_2712.jpg";
gPhotos[16].ImageWidth = 450;
gPhotos[16].ImageHeight = 299;
gPhotos[16].ThumbWidth = 75;
gPhotos[16].ThumbHeight = 49;
gPhotos[16].meta = new Object();

gPhotos[17] = new Object();
gPhotos[17].filename = "DSC_0123_2713.jpg";
gPhotos[17].ImageWidth = 450;
gPhotos[17].ImageHeight = 299;
gPhotos[17].ThumbWidth = 75;
gPhotos[17].ThumbHeight = 49;
gPhotos[17].meta = new Object();

gPhotos[18] = new Object();
gPhotos[18].filename = "DSC_0125_2715.jpg";
gPhotos[18].ImageWidth = 450;
gPhotos[18].ImageHeight = 299;
gPhotos[18].ThumbWidth = 75;
gPhotos[18].ThumbHeight = 49;
gPhotos[18].meta = new Object();

gPhotos[19] = new Object();
gPhotos[19].filename = "DSC_0130_2720.jpg";
gPhotos[19].ImageWidth = 450;
gPhotos[19].ImageHeight = 299;
gPhotos[19].ThumbWidth = 75;
gPhotos[19].ThumbHeight = 49;
gPhotos[19].meta = new Object();

gPhotos[20] = new Object();
gPhotos[20].filename = "DSC_0133_2723.jpg";
gPhotos[20].ImageWidth = 450;
gPhotos[20].ImageHeight = 299;
gPhotos[20].ThumbWidth = 75;
gPhotos[20].ThumbHeight = 49;
gPhotos[20].meta = new Object();

gPhotos[21] = new Object();
gPhotos[21].filename = "DSC_0134_2724.jpg";
gPhotos[21].ImageWidth = 450;
gPhotos[21].ImageHeight = 299;
gPhotos[21].ThumbWidth = 75;
gPhotos[21].ThumbHeight = 49;
gPhotos[21].meta = new Object();

gPhotos[22] = new Object();
gPhotos[22].filename = "DSC_0135_2725.jpg";
gPhotos[22].ImageWidth = 450;
gPhotos[22].ImageHeight = 299;
gPhotos[22].ThumbWidth = 75;
gPhotos[22].ThumbHeight = 49;
gPhotos[22].meta = new Object();

gPhotos[23] = new Object();
gPhotos[23].filename = "DSC_0136_2726.jpg";
gPhotos[23].ImageWidth = 450;
gPhotos[23].ImageHeight = 299;
gPhotos[23].ThumbWidth = 75;
gPhotos[23].ThumbHeight = 49;
gPhotos[23].meta = new Object();

gPhotos[24] = new Object();
gPhotos[24].filename = "DSC_0137_2727.jpg";
gPhotos[24].ImageWidth = 450;
gPhotos[24].ImageHeight = 299;
gPhotos[24].ThumbWidth = 75;
gPhotos[24].ThumbHeight = 49;
gPhotos[24].meta = new Object();

